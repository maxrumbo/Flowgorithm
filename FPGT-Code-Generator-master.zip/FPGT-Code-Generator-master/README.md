# Flowgorithm-Code-Generator
Flowgorithm Code Generator for flowgorithm flow chart interpreter.<br/>
<br/>
Steps to use the tool.<br/>
Step 1: Download the Flowgorithm tool from http://flowgorithm.org/download/index.htm <br/>
Step 2: Download julia.fpgt file from this repository <br/>
Step 3: Install Flowgorithm tool <br/>
Step 4: Start the application and begin drawing flow chart <br/>
Step 5: Once flow chart is drawn select julia.fpgt file to generate julia source code<br/>
